Labrys Brand Kit
================

This bundle contains official Labrys logos in SVG and PNG formats.

Variants:
  - mark      — square icon, for app icons / favicons
  - wordmark  — "Labrys" text logo, for headers
  - lockup    — mark + wordmark together, for primary brand placement

Themes:
  - dark      — dark-fill logos for use on light backgrounds
  - light     — white-fill logos for use on dark backgrounds

Formats:
  - .svg      — vector, scalable, preferred for web and print
  - .png      — raster, for slide decks and social media

Usage Guidelines
----------------

DO:
  - Preserve clear-space around the logo equal to the height of the mark.
  - Use the dark-fill logo on light backgrounds, white-fill on dark.
  - Scale proportionally.

DON'T:
  - Recolor or apply effects (shadows, gradients, outlines).
  - Rotate or distort the logo.
  - Place on backgrounds that compromise contrast or legibility.
  - Use older Labrys logos found elsewhere on the web.

For full brand guidelines visit: https://labrys.io/brand-assets
Questions: info@labrys.io
